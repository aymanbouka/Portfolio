print("Please enter your birth year")

userInput = int(input("input here: "))

age = 2022 - userInput

dogYear = age * 7

print("your age in dog years would be: ", dogYear)